angular.module('amg', [])
.directive('dash', function () { return {}; });
