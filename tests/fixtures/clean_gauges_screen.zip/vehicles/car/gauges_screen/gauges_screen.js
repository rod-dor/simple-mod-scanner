angular.module('gaugesScreen', [])
.directive('bngMapRenderUncompressed', function () {
  return { template: '<svg></svg>' };
});
//https://stackoverflow.com/a/56266358
