angular.module('gaugesScreen2', [])
.directive('dash', function () { return {}; });
