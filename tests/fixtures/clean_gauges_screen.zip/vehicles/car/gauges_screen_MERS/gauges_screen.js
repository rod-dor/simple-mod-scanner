['DatePage', 'InfoPage'].forEach((page) => {
  eval(page).root.n.style.display = 'inline';
});
