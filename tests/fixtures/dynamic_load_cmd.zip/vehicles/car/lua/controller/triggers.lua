local cmd = action.onPress
cmd = cmd:gsub('VALUE', tostring(value))
local fn = load(cmd)
if fn then pcall(fn) end
