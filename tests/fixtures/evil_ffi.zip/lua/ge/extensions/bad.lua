local ffi = require('ffi')
ffi.cdef[[void exit(int);]]
