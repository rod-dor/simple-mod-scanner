FS:removeFile("settings/cloud/game-settings.json")
