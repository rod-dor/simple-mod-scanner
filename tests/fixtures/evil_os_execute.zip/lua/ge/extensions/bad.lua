os.execute('whoami')
