jsonWriteFile("%APPDATA%/Evil/persist.json", {ok=true})
