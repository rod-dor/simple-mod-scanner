extensions.load('trueBeamTouch')
load('radarDetectorCore')
obj:queueGameEngineLua("extensions.load('parktronicge')")
