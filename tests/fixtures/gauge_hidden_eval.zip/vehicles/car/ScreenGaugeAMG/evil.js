eval(page).ok = true;
eval('alert(1)');
